<?php
require "autoloads.php";
use ApiRoutes\Routes;

Routes::methods();  
 

/* $router = new Router(new Request);
$router->get('/api/v1/pdf', function() {
    echo "principal jejeje";
});  */
 
?>