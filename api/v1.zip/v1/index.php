<?php
require "autoloads.php";

use ApiRoutes\Routes;

Routes::methods(); 


/* include_once 'App/Request.php';
include_once 'App/Router.php';



$router = new Router(new Request);
$router->get('/api/v1/', function() {
    echo "principal jejeje";
});
 */


?>