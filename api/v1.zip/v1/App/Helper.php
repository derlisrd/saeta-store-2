<?php


namespace Helper;

class Helper{


    public static function NumberToLetterES($number){
        return $number;
    }

    
}