<?php
interface IRequest
{
    public function getBody();
}